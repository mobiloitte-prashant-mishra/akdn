jQuery(document).ready(function() {
      jQuery(" .image-right-align .field-type-text-with-summary p:nth-child(4) img").not('[src*="pdf.png"]').addClass('image-side_image large-image');
});
;
;
